abstract class Goal
{
    private string _name;
    private string _description;
    private int _points;
    private bool _isCompleted;

    public string Name { get { return _name; } }
    public string Description { get { return _description; } }
    public int Points { get { return _points; } }
    public bool IsCompleted { get { return _isCompleted; } }

    protected Goal(string name, string description, int points)
    {
        _name = name;
        _description = description;
        _points = points;
        _isCompleted = false;
    }

    public abstract void RecordEvent();
    public abstract bool IsComplete();

    protected void Complete()
    {
        _isCompleted = true;
    }
}
