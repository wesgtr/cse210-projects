class ChecklistGoal : Goal
{
    private int _requiredCount;
    private int _currentCount;
    private int _bonusPoints;

    public int RequiredCount { get { return _requiredCount; } }
    public int CurrentCount { get { return _currentCount; } }
    public int BonusPoints { get { return _bonusPoints; } }

    public ChecklistGoal(string name, string description, int points, int requiredCount, int bonusPoints)
        : base(name, description, points)
    {
        _requiredCount = requiredCount;
        _bonusPoints = bonusPoints;
        _currentCount = 0;
    }

    public override void RecordEvent()
    {
        if (!IsCompleted)
        {
            _currentCount++;
            if (_currentCount >= _requiredCount)
            {
                Complete();
            }
        }
    }

    public override bool IsComplete()
    {
        return IsCompleted;
    }
}
