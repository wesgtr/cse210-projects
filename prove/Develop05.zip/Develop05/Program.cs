class Program
{
    static void Main(string[] args)
    {
        EternalQuest quest = new EternalQuest();

        quest.AddGoal(new SimpleGoal("Run a Marathon", "Complete a marathon", 1000));
        quest.AddGoal(new EternalGoal("Read Scriptures", "Read scriptures daily", 100));
        quest.AddGoal(new ChecklistGoal("Attend Temple", "Attend the temple 10 times", 50, 10, 500));

        quest.RecordGoalEvent("Read Scriptures");
        quest.RecordGoalEvent("Attend Temple");

        quest.DisplayGoals();
        quest.DisplayScore();

        quest.Save("goals.txt");
        quest.Load("goals.txt");
    }
}
