using System;
using System.Collections.Generic;
using System.IO;

class EternalQuest
{
    private List<Goal> _goals;
    private int _score;

    public EternalQuest()
    {
        _goals = new List<Goal>();
        _score = 0;
    }

    public void AddGoal(Goal goal)
    {
        _goals.Add(goal);
    }

    public void RecordGoalEvent(string goalName)
    {
        foreach (var goal in _goals)
        {
            if (goal.Name == goalName)
            {
                goal.RecordEvent();
                _score += goal.Points;
                if (goal is ChecklistGoal checklistGoal && checklistGoal.IsComplete())
                {
                    _score += checklistGoal.BonusPoints;
                }
                break;
            }
        }
    }

    public void DisplayGoals()
    {
        foreach (var goal in _goals)
        {
            Console.WriteLine($"{goal.Name}: {goal.Description} - Completed: {goal.IsComplete()}");
            if (goal is ChecklistGoal checklistGoal)
            {
                Console.WriteLine($"Progress: {checklistGoal.CurrentCount}/{checklistGoal.RequiredCount}");
            }
        }
    }

    public void DisplayScore()
    {
        Console.WriteLine($"Current Score: {_score}");
    }

    public void Save(string filePath)
    {
        using (StreamWriter writer = new StreamWriter(filePath))
        {
            writer.WriteLine(_score);
            foreach (var goal in _goals)
            {
                writer.WriteLine($"{goal.GetType().Name},{goal.Name},{goal.Description},{goal.Points},{goal.IsComplete()}");
                if (goal is ChecklistGoal checklistGoal)
                {
                    writer.WriteLine($"{checklistGoal.RequiredCount},{checklistGoal.CurrentCount},{checklistGoal.BonusPoints}");
                }
            }
        }
    }

    public void Load(string filePath)
    {
        using (StreamReader reader = new StreamReader(filePath))
        {
            _score = int.Parse(reader.ReadLine());
            _goals.Clear();

            string line;
            while ((line = reader.ReadLine()) != null)
            {
                string[] parts = line.Split(',');

                if (parts.Length >= 5) // Ensure the minimum number of elements
                {
                    if (parts[0] == nameof(SimpleGoal))
                    {
                        var goal = new SimpleGoal(parts[1], parts[2], int.Parse(parts[3]));
                        if (bool.Parse(parts[4])) goal.RecordEvent();
                        _goals.Add(goal);
                    }
                    else if (parts[0] == nameof(EternalGoal))
                    {
                        var goal = new EternalGoal(parts[1], parts[2], int.Parse(parts[3]));
                        _goals.Add(goal);
                    }
                    else if (parts[0] == nameof(ChecklistGoal) && parts.Length >= 7)
                    {
                        var goal = new ChecklistGoal(parts[1], parts[2], int.Parse(parts[3]), int.Parse(parts[5]), int.Parse(parts[6]));
                        for (int i = 0; i < int.Parse(parts[4]); i++) goal.RecordEvent();
                        _goals.Add(goal);
                    }
                }
                else
                {
                    Console.WriteLine($"Error: Invalid line format - {line}");
                }
            }
        }
    }
}
